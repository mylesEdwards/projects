import re
import numpy as np
import pandas as pd
import pymongo 

# -------------------------
# MongoDB Setup
# -------------------------
MONGO_URI = "mongodb+srv://myleszero5_db_user:S60yUunjF7ifssuG@cluster0.3xd4wo3.mongodb.net/" 
DB_NAME = "Hospital"
MAPPING_COLLECTION = "ICD-10"

# Global dictionary: {un-normalized_keyword_phrase: canonical_symptom_name}
SYMPTOM_KEYWORD_MAP = {} 

# Helper Functions

# NOTE: normalize_phrase is unused but kept for historical context.
def normalize_phrase(phrase):
    """Lowercase, strip, and sort words to normalize keyword order."""
    words = phrase.lower().split()
    words.sort()
    return " ".join(words)

def save_to_mongodb(df, collection_name="Transcripts_Processed"):
    """Saves the processed DataFrame to a new MongoDB collection."""
    try:
        client = pymongo.MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        db = client[DB_NAME]
        
        # Select the target collection and clear old data for this example
        collection = db[collection_name]
        collection.drop() 
        
        # Convert the DataFrame records to a list of dictionaries
        data_records = df.to_dict('records')
        
        # Insert the records
        collection.insert_many(data_records)
        print(f"\nSUCCESS: Processed data saved to MongoDB collection: {collection_name}")
        print(f"Total documents inserted: {len(data_records)}")
        return True
    except Exception as e:
        print(f"\nFATAL ERROR: Could not save data to MongoDB: {e}")
        return False

# -------------------------
# Load symptom mapping rules from MongoDB
# -------------------------
def load_mongo_rules():
    """Fetches all symptom keywords and maps them to their canonical symptom name."""
    global SYMPTOM_KEYWORD_MAP
    SYMPTOM_KEYWORD_MAP = {}
    
    try:
        client = pymongo.MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        client.admin.command('ping')
        db = client[DB_NAME]
        
        mongo_mappings = list(db[MAPPING_COLLECTION].find({}, {'_id': 0, 'symptom_keywords': 1}))
        
        for doc in mongo_mappings:
            if 'symptom_keywords' in doc:
                keywords = [k.strip() for k in doc['symptom_keywords'].split(';')]
                canonical_name = keywords[0] if keywords else None

                if canonical_name:
                    for keyword in keywords:
                        # Clean and lowercase the keyword phrase
                        cleaned_keyword = re.sub(r'[^a-z0-9\s]', '', keyword).strip().lower()
                        
                        if cleaned_keyword:
                            # Use the un-normalized, cleaned keyword as the map key
                            SYMPTOM_KEYWORD_MAP[cleaned_keyword] = canonical_name.title()

        print(f"Successfully loaded {len(SYMPTOM_KEYWORD_MAP)} symptom keywords from MongoDB.")
        return True

    except Exception as e:
        print(f"WARNING: Could not connect to MongoDB: {e}. Using fallback.")
        fallback = {
            "tonsillar exudate": "Tonsillar Exudate",
            "sore throat": "Tonsillar Exudate",
            "swallow": "Tonsillar Exudate",
            "tired than usual": "Tired Than Usual",
            "fatigue": "Tired Than Usual",
            "dizziness": "Tired Than Usual",
            "cough": "Cough",
            "difficulty breathing": "Cough",
            "high blood pressure": "High Blood Pressure",
            "blood pressure high": "High Blood Pressure",
            "headache": "High Blood Pressure",
            "irregular heartbeat": "Irregular Heartbeat"
        }
        for k, v in fallback.items():
            cleaned_keyword = re.sub(r'[^a-z0-9\s]', '', k).strip().lower()
            if cleaned_keyword:
                SYMPTOM_KEYWORD_MAP[cleaned_keyword] = v
        return False

# -------------------------
# Load transcript data
# -------------------------
try:
    # Loads the combined_data.csv created by deserialization.py
    combined_df = pd.read_csv('combined_data.csv')
    print("Successfully loaded combined_data.csv for NLP processing.")
except FileNotFoundError:
    print("FATAL ERROR: combined_data.csv not found.")
    exit()

# Load rules from MongoDB
load_mongo_rules()

# -------------------------
# Symptom Extraction & Redaction
# -------------------------
def extract_and_redact(transcript):
    if pd.isna(transcript):
        return "", ""

    lower_transcript = transcript.lower()
    
    # Redaction
    redacted_text = re.sub(
        r'(John Doe|Mrs\. Patel|Sarah|12/15/1985|112233|adam|miles)',
        '<<REDACTED>>',
        transcript
    )

    canonical_symptoms = []
    
    for keyword_phrase, canonical_name in SYMPTOM_KEYWORD_MAP.items():
        if re.search(re.escape(keyword_phrase), lower_transcript):
            canonical_symptoms.append(canonical_name)

    canonical_symptoms = list(set(canonical_symptoms))
    return redacted_text, "; ".join(canonical_symptoms)

# -------------------------
# Talk Ratio Calculator
# -------------------------
def calculate_talk_ratio(transcript):
    if pd.isna(transcript):
        return 0, 0
        
    patient_text = " ".join(re.findall(r'Patient:\s(.*?)(?=\nDoctor:|\Z)', transcript, re.DOTALL))
    doctor_text  = " ".join(re.findall(r'Doctor:\s(.*?)(?=\nPatient:|\Z)', transcript, re.DOTALL))
    
    patient_words = len(patient_text.split())
    doctor_words  = len(doctor_text.split())
    total_words   = patient_words + doctor_words
    
    if total_words == 0:
        return 0, 0
        
    return patient_words / total_words, total_words

# -------------------------
# Apply NLP to DataFrame
# -------------------------
combined_df[['redacted_transcript', 'extracted_symptoms']] = combined_df['transcript_conv'].apply(
    lambda x: pd.Series(extract_and_redact(x))
)

combined_df[['patient_talk_ratio', 'total_words']] = combined_df['transcript_conv'].apply(
    lambda x: pd.Series(calculate_talk_ratio(x))
)

# -------------------------
# Export processed data (SAVES TO CSV AND MONGO)on
# -------------------------
combined_df.to_csv('processed_data.csv', index=False)
print("SUCCESS: Finished NLP processing. Output file 'processed_data.csv' created.")

# --- NEW STEP: Save the processed DataFrame to MongoDB ---
save_to_mongodb(combined_df, "Transcripts_Processed")
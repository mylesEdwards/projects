import pandas as pd
import numpy as np
import pymongo
import re

# --- Helper Functions ---
def normalize_phrase(phrase):
    """Lowercase, strip, and sort words to normalize keyword order."""
    # ------------------ FIX START ------------------
    # 1. Check if the value is NaN (float) or not a string.
    if pd.isna(phrase) or not isinstance(phrase, str):
        return ""
    
    # 2. Check if the string is empty after stripping whitespace.
    if not phrase.strip():
        return ""
    # ------------------- FIX END -------------------
    
    words = phrase.lower().split()
    words.sort()
    return " ".join(words)

# --- MongoDB Setup ---
MONGO_URI = "mongodb+srv://myleszero5_db_user:S60yUunjF7ifssuG@cluster0.3xd4wo3.mongodb.net/"
DB_NAME = "Hospital"
MAPPING_COLLECTION = "ICD-10"

# Global mapping cache: {normalized_canonical_symptom_name: ICD_Code}
ICD_CODE_MAP = {}

# --- Load ICD Mapping ---
def load_icd_map():
    """Loads the canonical symptom to ICD code map from MongoDB (Canonical Symptom -> ICD Code)."""
    global ICD_CODE_MAP
    ICD_CODE_MAP = {}

    try:
        client = pymongo.MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        client.admin.command('ping')
        db = client[DB_NAME]

        mongo_mappings = list(db[MAPPING_COLLECTION].find({}, 
                                                           {'_id': 0, 'symptom_keywords': 1, 'icd_code': 1}))

        for doc in mongo_mappings:
            if 'symptom_keywords' in doc and 'icd_code' in doc:
                keywords = [k.strip().lower() for k in doc['symptom_keywords'].split(';')]
                canonical_name = keywords[0].title() if keywords and keywords[0] else None

                if canonical_name:
                    normalized_name = normalize_phrase(canonical_name)
                    ICD_CODE_MAP[normalized_name] = doc['icd_code']

        print(f"Successfully built ICD mapping for {len(ICD_CODE_MAP)} canonical symptoms.")
        return True

    except Exception as e:
        print(f"WARNING: Could not connect to MongoDB for ICD mapping: {e}. Using fallback map.")
        fallback = {'Cough': 'J18.9',
                    'High Blood Pressure': 'I10',
                    'Tonsillar Exudate': 'J02.9',
                    'Tired Than Usual': 'R68.8'}
        for k, v in fallback.items():
            ICD_CODE_MAP[normalize_phrase(k)] = v
        return False

# --- EXECUTION STARTS HERE ---
if not load_icd_map():
    pass  # Fallback map will be used

try:
    combined_df = pd.read_csv('processed_data.csv')
    print("Successfully loaded processed_data.csv for correlation mapping.")
except FileNotFoundError:
    print("FATAL ERROR: processed_data.csv not found. Did NLP.py run successfully?")
    exit()

# --- Symptom-to-Diagnosis Co-occurrence ---
# 1. Explode the list of symptoms
symptom_map_df = combined_df.assign(
    extracted_symptoms=combined_df['extracted_symptoms'].apply(
        lambda x: [s.strip() for s in x.split(';')] if pd.notna(x) and x else []
    )
).explode('extracted_symptoms')

# 2. Map extracted symptoms to ICD codes using normalized keys
symptom_map_df['ICD_Code'] = symptom_map_df['extracted_symptoms'].apply(
    lambda s: ICD_CODE_MAP.get(normalize_phrase(s), 'UNMATCHED')
)

# 3. Remove unmatched codes and empty entries
symptom_map_df = symptom_map_df[symptom_map_df['ICD_Code'] != 'UNMATCHED']
symptom_map_df = symptom_map_df[symptom_map_df['extracted_symptoms'].str.strip() != '']

if symptom_map_df.empty:
    print("WARNING: No matched symptoms. Skipping matrix.")
    correlation_matrix = pd.DataFrame()
else:
    # 4. Create binary co-occurrence matrix (Symptom vs ICD)
    co_occurrence = symptom_map_df.groupby(['extracted_symptoms', 'ICD_Code']).size().reset_index(name='Count')
    correlation_matrix = co_occurrence.pivot_table(index='extracted_symptoms', columns='ICD_Code', values='Count', fill_value=0)
    correlation_matrix = (correlation_matrix > 0).astype(int)  # Convert counts to binary

# --- Talk Ratio Correlation ---
talk_ratio_correlation = combined_df['patient_talk_ratio'].corr(combined_df['total_words'])

# --- Output Results ---
print("\n--- Correlation Results ---")
print("\nSymptom-to-Diagnosis Co-occurrence Matrix:")
print(correlation_matrix.to_markdown(index=True, numalign="left", stralign="left"))
print("\nCorrelation between Patient Talk Ratio and Total Conversation Words:", talk_ratio_correlation)
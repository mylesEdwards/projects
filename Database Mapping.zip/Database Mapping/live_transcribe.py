import numpy as np            # For working with audio data as numeric arrays
import sounddevice as sd      # For recording audio from the microphone
import whisper                # For loading and running the Whisper model
import torch                  # For checking if a GPU (CUDA) is available
from bson import BSON
import datetime
import random
import time                   # Added for time.sleep

SAMPLE_RATE = 16_000          
CHUNK_SECONDS = 8             
MODEL_NAME = "small.en"       
USE_GPU = True                


def choose_device(use_gpu_flag):
    # Check if we should try to use the GPU
    if use_gpu_flag and torch.cuda.is_available():
        # If USE_GPU is True and CUDA is available, use the GPU
        return "cuda"
    # Otherwise, fall back to CPU
    return "cpu"


def record_chunk(duration_seconds, sample_rate):
    # Calculate the number of audio samples needed for the given duration
    num_samples = int(duration_seconds * sample_rate)

    # Start recording audio from the default microphone
    audio = sd.rec(
        num_samples,
        samplerate=sample_rate,
        channels=1,
        dtype="float32"
    )

    # Wait until the recording is finished before continuing
    sd.wait()

    # Flatten the array from shape (num_samples, 1) to (num_samples,)
    return audio.flatten()

def transcribe_chunk(model, audio_data, device):
    # Load the model if it hasn't been loaded yet
    if model is None:
        print(f"Loading Whisper model '{MODEL_NAME}' on {device}. This may take some time...")
        # Force model to be loaded once
        model = whisper.load_model(MODEL_NAME, device=device)
    
    # Process the audio data (which should be a numpy array of float32)
    # Whisper expects a tensor, so convert the numpy array
    audio_tensor = torch.from_numpy(audio_data).to(device)
    
    # Use the model to transcribe the audio
    result = model.transcribe(audio_tensor, fp16=False)
    
    return result['text'], model


#                   MAIN FUNCTION 
def main():
    device = choose_device(USE_GPU)
    model = None  # Model starts as None and is loaded on the first transcription
    segments = [] # List to store all transcribed segments
    chunk_count = 0

    print(f"Recording audio in {CHUNK_SECONDS}-second chunks. Press Ctrl+C to stop.")

    try:
        while True:
            # --- NEW SPEAKER LABEL PROMPT ---
            speaker = input("Is the speaker the **Patient** or **Doctor**? (P/D): ").strip().upper()
            if speaker == 'P':
                speaker_label = "Patient:"
            elif speaker == 'D':
                speaker_label = "Doctor:"
            else:
                print("Invalid input. Defaulting to Patient: and waiting 2 seconds.")
                speaker_label = "Patient:"
                time.sleep(2)
            # --- END NEW SPEAKER LABEL PROMPT ---

            chunk_count += 1
            print(f"\nRecording chunk {chunk_count} ({CHUNK_SECONDS} seconds) for {speaker_label}")

            audio_data = record_chunk(CHUNK_SECONDS, SAMPLE_RATE)
            print("Transcribing...")
            
            # The model is loaded here on the first run
            text, model = transcribe_chunk(model, audio_data, device)
            
            # Store the speaker label and text together, formatted correctly for NLP.py regex
            formatted_text = f"{speaker_label} {text.strip()}"
            segments.append(formatted_text)
            # --- END MODIFIED SEGMENT STORAGE ---

            # Print the transcription of the current chunk
            print(formatted_text)

    except KeyboardInterrupt:
        print("\nStopping live transcription.")
        
        # --- BSON EXPORT FOR ANALYSIS PIPELINE (MODIFIED) ---

        # 1. Concatenate all transcribed segments with a newline separator
        #    This is CRITICAL for the talk ratio regex in NLP.py to work.
        full_transcript = "\n".join(segments)

        # Generate a unique ID and current date for the document
        transcript_id = f"T{random.randint(1000, 9999)}" 
        current_date = datetime.date.today().strftime("%Y-%m-%d")

        # 2. Assemble the final document structure
        transcript_document = {
            'transcript_id': transcript_id,
            'date': current_date,
            'transcript': full_transcript
        }

        # 3. Write the document to the required BSON file
        #    NOTE: Since you are running multiple times, it is better to save with the ID.
        #    However, to match your current pipeline, we stick to the original filename.
        output_filename = f"audio_transcripts_{transcript_id}.bson"
        with open(output_filename, 'wb') as f:
            f.write(BSON.encode(transcript_document))

        print(f"\nSuccessfully saved transcript data to {output_filename} (ID: {transcript_id}).")


# Make sure main() runs only when this file is executed directly
if __name__ == "__main__":
    main()

    # 1. Specify the 'current' mode argument
#python3 deserialization.py current
# Expected Output: Total Records: 1

# 2. Run the rest of the pipeline
#python3 NLP.py
#python3 SymToDiag_Mapping.py

# RESULT: Matrix is clean (Patient-specific), Correlation is NaN (as expected).

### **Mode B: Historical Correlation Analysis (Total Records: 2+)**

#Use this mode when you want to calculate the statistical trend (correlation) across all patients you have ever recorded. This mode loads all unique BSON files.

#***Note: You must have at least 2 clean BSON files in your directory for this to work.***

#```bash
# 1. Specify the 'historical' mode argument
#python3 deserialization.py historical
# Expected Output: Total Records: [Number of all unique files, e.g., 4]

# 2. Run the rest of the pipeline
#python3 NLP.py
#python3 SymToDiag_Mapping.py

# RESULT: Matrix is composite (all patients), Correlation is a valid number (non-NaN).


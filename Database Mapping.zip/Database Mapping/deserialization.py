import pandas as pd
from bson import BSON
import os
import random 
import glob 
import time 
import sys # <-- NEW: Import sys for command-line arguments

# MongoDB Setup Variables (Kept for reference, but no connection is made here)
MONGO_URI = "mongodb+srv://myleszero5_db_user:S60yUunjF7ifssuG@cluster0.3xd4wo3.mongodb.net/" 
DB_NAME = "Hospital"
MAPPING_COLLECTION = "ICD-10"
OUTPUT_FILE = 'combined_data.csv' 

# --- Function to Load BSON Data Safely ---
def load_bson_data(file_path):
    """Loads BSON data from a single file and converts it to a DataFrame."""
    
    if not os.path.exists(file_path):
        return pd.DataFrame()

    print(f"Loading data from {file_path}...")
    
    with open(file_path, 'rb') as f:
        raw_data = f.read()
        
    if not raw_data:
        print(f"Warning: BSON file '{file_path}' is empty.")
        return pd.DataFrame()

    try:
        doc = BSON.decode(raw_data)
        # Create DataFrame from a list containing the single document
        df = pd.DataFrame([doc])
        
        # Add mock columns expected by the subsequent NLP and Mapping scripts
        df['Primary Diagnosis'] = 'MOCK_DIAGNOSIS_' + str(random.randint(100, 999))
        df['Patient Name'] = '<<TEST_USER>>'
        
        return df
    except Exception as e:
        print(f"Error decoding BSON from {file_path}: {e}")
        return pd.DataFrame()


# ----------------------------------------------------
#               MAIN EXECUTION START 
# ----------------------------------------------------

# --- Determine Mode (Default to 'current' if no argument or unrecognized) ---
mode = 'current'
if len(sys.argv) > 1:
    if sys.argv[1].lower() == 'historical':
        mode = 'historical'
    elif sys.argv[1].lower() == 'current':
        mode = 'current'

all_transcripts = []

# 1. Find all BSON files with a unique ID (audio_transcripts_T*.bson)
all_bson_files = glob.glob('audio_transcripts_T*.bson') 

if not all_bson_files:
    print("FATAL ERROR: No 'audio_transcripts_T*.bson' files found. Please run live_transcribe.py first.")
    exit()

# 2. Select files based on mode
if mode == 'current':
    # Current Patient Mode: Load only the single, most recent file
    
    # Sort files by creation time (most recent first)
    all_bson_files.sort(key=os.path.getmtime, reverse=True)
    
    # Select ONLY the most recent file
    bson_files_to_load = [all_bson_files[0]]
    print(f"\nAttempting to load CURRENT PATIENT transcript: {bson_files_to_load[0]}")
    
elif mode == 'historical':
    # Historical Mode: Load ALL unique BSON files
    
    bson_files_to_load = all_bson_files
    print(f"\nAttempting to load ALL {len(bson_files_to_load)} HISTORICAL transcripts...")

# 3. Load the selected file(s)
for file_path in bson_files_to_load:
    df = load_bson_data(file_path)
    if not df.empty:
        all_transcripts.append(df)

if all_transcripts:
    # Concatenate all DataFrames into one
    combined_df = pd.concat(all_transcripts, ignore_index=True)
    
    # Rename 'transcript' column to 'transcript_conv' as expected by NLP.py
    if 'transcript' in combined_df.columns:
        combined_df.rename(columns={'transcript': 'transcript_conv'}, inplace=True)
    
    combined_df.to_csv(OUTPUT_FILE, index=False)
    
    print("\n--- SUCCESS: Deserialization Complete ---")
    print(f"Data saved to {OUTPUT_FILE}")
    print(f"Total Records: {len(combined_df)}")
else:
    print("\nFATAL ERROR: BSON files found but failed to load any data.")